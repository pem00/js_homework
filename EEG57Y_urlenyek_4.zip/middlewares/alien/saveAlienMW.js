/*
    Saves the modified or new entry of an alien using POST
    redirects to /overview after success
*/
module.exports = function(objRepo) {
    return function(req, res, next) {
            return next();
    }
}