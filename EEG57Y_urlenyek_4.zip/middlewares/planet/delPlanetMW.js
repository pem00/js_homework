/*
    Removes the choosen bolygó from the database.
    Redirects to /overview
*/
module.exports = function(objRepo) {
    return function(req, res, next) {
            return next();
    }
}