const express = require('express');
const app = express();

app.set('view engine', 'ejs');

app.get('/', (req, res, next) => {
    res.render('home');
})

app.get('/overview', (req, res, next) => {
    res.send('Overview');
})

app.get('/add-new-alien', (req, res, next) => {
    res.send('add-new-alien');
})

app.get('/add-new-planet', (req, res, next) => {
    res.send('add-new-planet');
})

app.listen(3000, () => {
    console.log('Running on :3000');
})

