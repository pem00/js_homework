const  mongoose = require('mongoose');
mongoose.connect('mpngodb://localhost//eeg57y');

module.exports = mongoose;