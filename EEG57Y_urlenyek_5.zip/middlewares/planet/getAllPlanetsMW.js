/*
    Load all űrlények from teh database
*/
module.exports = function(objRepo) {
    return function(req, res, next) {
            return next();
    }
}