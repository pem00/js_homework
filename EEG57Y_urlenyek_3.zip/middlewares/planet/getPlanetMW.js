/*
    Load one planets from the database
*/
module.exports = function(objRepo) {
    return function(req, res, next) {
            return next();
    }
}